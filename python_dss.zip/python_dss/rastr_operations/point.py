"""
Точка на графике (дубликат для совместимости)
"""

from models.point import Point

__all__ = ['Point']

