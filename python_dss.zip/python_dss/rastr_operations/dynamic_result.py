"""
Результат динамического расчета (дубликат для совместимости)
"""

from models.dynamic_result import DynamicResult

__all__ = ['DynamicResult']

