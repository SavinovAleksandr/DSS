"""
Операции с Excel файлами
"""

from .excel_operations import ExcelOperations

__all__ = ['ExcelOperations']

