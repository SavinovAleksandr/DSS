"""
Тесты для StabLimit
"""

