"""
Результат расчета шунта КЗ (дубликат для совместимости)
"""

from models.shunt_kz_result import ShuntKZResult

__all__ = ['ShuntKZResult']

