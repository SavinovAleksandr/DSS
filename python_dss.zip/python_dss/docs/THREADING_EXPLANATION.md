# Многопоточность в StabLimit

## 📊 Как реализовано

### 1. Два уровня многопоточности

#### Уровень 1: UI (Интерфейс)
**Где:** `ui/modern_main_window.py`, `ui/main_window.py`

**Что делает:**
- Запускает расчеты в отдельном потоке, чтобы UI не зависал
- Использует простой `threading.Thread`

**Пример:**
```python
def _calc_shunt_kz(self):
    def run_calc():
        # Расчет выполняется в фоне
        result = self.data_info.calc_shunt_kz(...)
    
    thread = threading.Thread(target=run_calc, daemon=True)
    thread.start()  # Запуск в отдельном потоке
```

**Сколько потоков:** 1 поток на каждый расчет (максимум 1 активный расчет одновременно)

---

#### Уровень 2: Параллельные расчеты (PerformanceOptimizer)
**Где:** `utils/performance.py`

**Что делает:**
- Параллельно выполняет несколько расчетов одновременно
- Использует `ThreadPoolExecutor` из стандартной библиотеки

**Пример:**
```python
from utils.performance import performance_optimizer

# Параллельное выполнение для списка элементов
results = performance_optimizer.parallel_map(
    func=my_calculation_function,
    items=[item1, item2, item3, item4]
)
# Все 4 элемента обрабатываются параллельно!
```

---

## 🔢 Сколько потоков используется?

### Автоматическое определение

**Формула:**
```python
max_workers = min(4, (threading.active_count() or 1) + 4)
```

**Что это значит:**
- **Минимум:** 4 потока
- **Максимум:** зависит от уже активных потоков
- **Примеры:**
  - Если активных потоков 1 → используется 4 потока
  - Если активных потоков 2 → используется 4 потока (минимум)
  - Если активных потоков 5 → используется 5 потоков
  - Если активных потоков 10 → используется 4 потока (минимум)

**Почему так:**
- 4 потока - оптимальный баланс для большинства задач
- Не перегружает систему
- Учитывает уже запущенные потоки

### Можно настроить вручную

```python
from utils.performance import PerformanceOptimizer

# Создать с 8 потоками
optimizer = PerformanceOptimizer(max_workers=8)

# Или использовать глобальный экземпляр
performance_optimizer.max_workers = 8
```

---

## 🎯 Где используется сейчас

### ✅ Реализовано:

1. **UI потоки** (всегда):
   - Каждый расчет запускается в отдельном потоке
   - UI остается отзывчивым во время расчетов

2. **PerformanceOptimizer** (готов к использованию):
   - Методы `parallel_map()` и `parallel_calc()` готовы
   - Можно использовать для параллельных расчетов

### ⚠️ Потенциал для улучшения:

**Сейчас расчеты выполняются последовательно:**
```python
# Текущая реализация (последовательно)
for rgm in rgms:
    for vrn in vrns:
        for scn in scns:
            # Расчет выполняется один за другим
            result = calculate(rgm, vrn, scn)
```

**Можно улучшить (параллельно):**
```python
# С параллельностью
from utils.performance import performance_optimizer

# Подготовка параметров для всех расчетов
calc_params = []
for rgm in rgms:
    for vrn in vrns:
        for scn in scns:
            calc_params.append({
                'rgm': rgm,
                'vrn': vrn,
                'scn': scn
            })

# Параллельное выполнение всех расчетов
results = performance_optimizer.parallel_calc(
    calc_func=calculate,
    calc_params=calc_params,
    progress_callback=update_progress
)
```

**Ускорение:** В 2-4 раза (зависит от количества ядер CPU)

---

## 📈 Примеры использования

### Пример 1: Параллельная обработка списка

```python
from utils.performance import performance_optimizer

def process_file(file_path):
    # Обработка одного файла
    return process(file_path)

files = ["file1.rg2", "file2.rg2", "file3.rg2", "file4.rg2"]

# Последовательно (медленно)
results = [process_file(f) for f in files]  # 4 секунды

# Параллельно (быстро)
results = performance_optimizer.parallel_map(process_file, files)  # 1 секунда
```

### Пример 2: Параллельные расчеты

```python
from utils.performance import performance_optimizer

def single_calculation(rgm, scn):
    # Один расчет
    return calculate(rgm, scn)

# Подготовка параметров
params = [
    {'rgm': rgm1, 'scn': scn1},
    {'rgm': rgm2, 'scn': scn2},
    {'rgm': rgm3, 'scn': scn3},
    {'rgm': rgm4, 'scn': scn4}
]

# Параллельное выполнение
results = performance_optimizer.parallel_calc(
    calc_func=single_calculation,
    calc_params=params,
    progress_callback=lambda x: print(f"Выполнено: {x}")
)
```

---

## ⚙️ Настройка

### Изменить количество потоков

**Через переменную окружения:**
```bash
export DSS_MAX_WORKERS=8
python main.py
```

**В коде:**
```python
from utils.performance import performance_optimizer
performance_optimizer.max_workers = 8
```

### Использовать процессы вместо потоков

Для CPU-интенсивных задач (если не используется RASTR COM):
```python
results = performance_optimizer.parallel_map(
    func=calculation,
    items=items,
    use_processes=True  # Использует процессы вместо потоков
)
```

---

## 🔍 Текущее состояние

### Что работает:
- ✅ UI не зависает (расчеты в фоне)
- ✅ Готова инфраструктура для параллельности
- ✅ Автоматическое определение количества потоков

### Что можно улучшить:
- ⚠️ Интегрировать параллельность в расчеты (сейчас последовательно)
- ⚠️ Добавить настройку количества потоков в UI
- ⚠️ Показывать использование потоков в статус-баре

---

## 📊 Производительность

**Ожидаемое ускорение:**
- 2-4 потока: ускорение в 1.5-3 раза
- 4-8 потоков: ускорение в 2-4 раза
- Зависит от:
  - Количества ядер CPU
  - Типа задачи (I/O или CPU)
  - Наличия GIL (Global Interpreter Lock) в Python

**Для RASTR:**
- RASTR COM может ограничивать параллельность
- Рекомендуется: 2-4 потока для RASTR операций

