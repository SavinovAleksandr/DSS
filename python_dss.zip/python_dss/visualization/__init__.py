"""
Модуль визуализации данных
"""

from .plotly_visualizer import PlotlyVisualizer

__all__ = ['PlotlyVisualizer']

